# CLAUDE.md / AGENTS.md — Guia do Projeto (Loja Online)

Este arquivo define **como o agente (Codex/Claude Code)** deve trabalhar neste repositório e quais são as regras do projeto.

> **Importante (pt-BR obrigatório para o usuário):** Todas as mensagens exibidas ao usuário (frontend e backend) devem estar em **Português (Brasil)**.  
> **Importante (código em inglês):** Todo código-fonte (nomes de arquivos, classes, métodos, variáveis e comentários técnicos) deve ser escrito em **inglês**.

---

## 1) O que é este projeto

Uma **loja online** com:
- **Angular 21** no frontend (UI profissional de e-commerce)
- **Node.js + TypeScript** no backend (API REST)
- **PostgreSQL** como banco relacional
- **RAG vetorial** usando **pgvector** (no PostgreSQL/Supabase) para pesquisa semântica baseada nos produtos

Perfis de acesso:
- `ADMIN` — acesso total (administração completa)
- `MANAGER` — acesso operacional (produtos/estoque, pedidos/vendas, RAG)
- `CUSTOMER` — comprador (catálogo, carrinho, checkout, minhas compras, perfil)

Fluxos principais:
- Customer: catálogo → carrinho → login no checkout → finalizar compra → minhas compras → cancelamento em até 3 dias se não entregue
- Admin/Manager: CRUD de produtos + estoque → pedidos/vendas → pesquisa RAG
- Sincronização: ao salvar/editar produto no relacional, gerar Markdown e indexar no pgvector (upsert vetorial)

---

## 2) Regras de idioma (obrigatórias)

### 2.1 Código-fonte (inglês)
- Classes, métodos, variáveis, nomes de arquivos, enums, interfaces e comentários técnicos: **em inglês**
- Comentário no topo de cada método: **máximo 2 linhas**, em inglês, explicando o propósito do método

### 2.2 Mensagens para usuário (pt-BR)
- Frontend: labels, botões, placeholders, mensagens de validação, feedback (toast/snackbar), erros e textos
- Backend: mensagens `mensagem` em responses, erros de validação e respostas de falha
- Exemplo de erro padronizado:
```json
{ "mensagem": "Não foi possível concluir a operação.", "detalhes": { "campo": "..." } }
```

---

## 3) Convenções e padrões

### 3.1 Arquitetura Backend (camadas)
- `routes` → `controllers` → `services` → `repositories`
- `services` concentram regras de negócio (checkout, cancelamento, status de pedido, RAG)
- `repositories` fazem queries SQL/ORM isoladas
- Middleware global de erro padroniza respostas (pt-BR)

### 3.2 Frontend (Angular 21)
- Preferir **Signals** para estado
- Preferir **Signal Forms** para formulários tipados
- Guards:
  - `authGuard`
  - `roleGuard` (ADMIN/MANAGER)
- Interceptor para JWT e interceptor para normalizar erros (pt-BR)

### 3.3 Testes
- Frontend: **Jest** (unit tests)
- Backend: unit tests para services (recomendado)

### 3.4 Qualidade
- Evitar `any` (usar `unknown` e refinar)
- Rodar lint antes de concluir uma entrega
- Entregas em etapas pequenas, com commits claros

---

## 4) Banco de dados

### 4.1 Relacional (PostgreSQL)
Entidades principais:
- users (roles + credenciais)
- customers_profile (cpf + dados pessoais + endereço)
- products + inventory
- orders + order_items (com snapshots)
- audit_log

Operações críticas sempre em transação:
- checkout: criar pedido + baixar estoque (com `SELECT ... FOR UPDATE`)
- cancelamento: validar regra + devolver estoque + status

### 4.2 Vetorial (pgvector)
Tabela sugerida `rag_products`:
- `product_id` (PK e referencia o produto)
- `content_markdown` (texto rico do produto)
- `embedding` (vector DIM)
- metadados (category, sale_price, weight, updated_at)

Regra:
- Ao criar/editar produto: salvar relacional → gerar markdown → gerar embedding → upsert em `rag_products`

---

## 5) Roadmap recomendado (etapas)

As etapas e checklists ficam em `/tasks/*.md`.  
**NUNCA** implementar tudo de uma vez. Execute etapa por etapa e sempre finalize com commit.

Exemplo de etapas:
- 00 bootstrap (frontend+backend+postgres)
- 01 auth + RBAC
- 02 customer profile
- 03 catalog
- 04 cart + checkout
- 05 minhas compras + cancelamento
- 06 admin produtos + estoque
- 07 rag (indexação + busca)
- 08 admin pedidos/status

---

## 6) Comandos de execução (ajuste conforme o repo)

### 6.1 Infra
- `docker compose up -d` (Postgres/Supabase local, se aplicável)

### 6.2 Backend
- `npm install`
- `npm run dev`
- `npm run lint`
- `npm test` (se configurado)

### 6.3 Frontend
- `npm install`
- `npm start`
- `npm run lint`
- `npm test` (Jest)

---

## 7) Como o agente deve trabalhar

### 7.1 Fluxo padrão por etapa
1. Ler o arquivo da etapa em `/tasks/<etapa>.md`
2. Implementar SOMENTE o escopo descrito
3. Garantir:
   - build ok
   - lint ok
   - testes ok (quando existirem)
4. Fazer **1 commit** com mensagem clara
5. Push para `main` (ver skill de commit/push)

### 7.2 Padrões para PR/commits
- Commits pequenos, mas completos por etapa
- Mensagem do commit:
  - resumo do que foi feito
  - opcional: lista curta de pontos principais

---

## 8) Prompt /init (quando existir no seu fluxo)

Quando o usuário pedir **/init**, o agente deve:
- Criar/atualizar este arquivo (CLAUDE.md e AGENTS.md) com as regras do projeto
- Garantir que a pasta `/tasks` exista e esteja atualizada
- Garantir que as regras de idioma (código em inglês e mensagens pt-BR) estejam explícitas

---

FIM.
